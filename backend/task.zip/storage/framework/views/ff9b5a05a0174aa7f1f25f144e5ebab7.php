

<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-3">
        <h1 class="h4 mb-0">Users</h1>
    </div>

    <div class="card shadow-sm mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="row g-2 align-items-end">
                <div class="col-12 col-md-6">
                    <label class="form-label">Search</label>
                    <input type="text" class="form-control" name="search" value="<?php echo e($search); ?>" placeholder="Search name/email">
                </div>
                <div class="col-12 col-md-auto">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Verified</th>
                        <th class="text-end"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-muted"><?php echo e($user->id); ?></td>
                            <td class="fw-semibold"><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php
                                    $roleClass = match ($user->role) {
                                        'manager' => 'bg-success',
                                        'admin' => 'bg-primary',
                                        default => 'bg-secondary',
                                    };
                                ?>
                                <span class="badge <?php echo e($roleClass); ?>"><?php echo e($user->role); ?></span>
                            </td>
                            <td>
                                <?php if($user->email_verified_at): ?>
                                    <span class="badge bg-success">yes</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">no</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="btn btn-outline-dark btn-sm">View</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">No users found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-body border-top">
            <?php echo e($users->withQueryString()->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Auth\task\resources\views/admin/users/index.blade.php ENDPATH**/ ?>