<p>Hello <?php echo e($name); ?>,</p>
<p>Your email verification code is: <strong><?php echo e($code); ?></strong></p>
<p>This code expires in 10 minutes.</p>
<?php /**PATH D:\Auth\task\resources\views/emails/email_verification_otp.blade.php ENDPATH**/ ?>