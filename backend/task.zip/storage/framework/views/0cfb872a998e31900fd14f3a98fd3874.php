

<?php $__env->startSection('title', 'Admin Overview'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-3">
        <h1 class="h4 mb-0">Overview</h1>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary btn-sm">Manage Users</a>
    </div>

    <div class="row g-3">
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted">Total users</div>
                    <div class="display-6"><?php echo e($stats['total_users']); ?></div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted">Verified users</div>
                    <div class="display-6"><?php echo e($stats['verified_users']); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm mt-3">
        <div class="card-header bg-white fw-semibold">Details</div>
        <div class="table-responsive">
            <table class="table table-striped mb-0">
                <tbody>
                    <tr><td>Admins</td><td class="text-end"><?php echo e($stats['admins_count']); ?></td></tr>
                    <tr><td>Managers</td><td class="text-end"><?php echo e($stats['managers_count']); ?></td></tr>
                    <tr><td>Created last 7 days</td><td class="text-end"><?php echo e($stats['created_last_7_days']); ?></td></tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Auth\task\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>